from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from google import genai
from google.genai import types
import os, json, base64
from dotenv import load_dotenv

load_dotenv()

# ── Setup ────────────────────────────────────────────────────
app = FastAPI()
client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

# Allow React frontend to talk to this backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request model ────────────────────────────────────────────
class TopicRequest(BaseModel):
    topic: str

# ── Health check ─────────────────────────────────────────────
@app.get("/")
def read_root():
    return {"status": "IllumiLearn Agent is running! 📚"}

# ── Main Agent Endpoint ──────────────────────────────────────
@app.post("/generate-story")
async def generate_story(request: TopicRequest):
    """
    This is the AGENT endpoint.
    It uses Gemini interleaved output to generate
    text + images together in one single stream.
    """

    topic = request.topic

    # This prompt tells Gemini to think like a creative director
    prompt = f"""
You are a creative educational storyteller agent for "IllumiLearn".
Your job is to create a 6-page illustrated storybook for kids aged 6-12 about: "{topic}"

For each page, you MUST:
1. Write a fun page title
2. Write 2-3 sentences of story text teaching through fun characters
3. Generate a colorful, child-friendly illustration for that page

After all 6 pages, create 3 quiz questions to test what the kid learned.

Think like a creative director — weave the story and images together naturally.
Make it magical, educational and fun!

Return your response as a JSON with this structure:
{{
  "pages": [
    {{
      "title": "Page title",
      "text": "Story text here",
      "imagePrompt": "Detailed image description for illustration"
    }}
  ],
  "quiz": [
    {{
      "question": "Question here?",
      "options": ["A", "B", "C", "D"],
      "correct": 0
    }}
  ]
}}
"""

    async def stream_storybook():
        """
        Streams the story generation progress to the frontend.
        This is the INTERLEAVED output the hackathon requires!
        """
        try:
            # Step 1: Generate the story structure with Gemini
            yield json.dumps({"type": "status", "message": "🔍 Understanding your topic..."}) + "\n"

            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0.8,
                    max_output_tokens=4096,
                )
            )

            story_data = json.loads(response.text)
            pages = story_data.get("pages", [])
            quiz = story_data.get("quiz", [])

            yield json.dumps({"type": "status", "message": "✍️ Story crafted! Now generating illustrations..."}) + "\n"

            # Step 2: For each page, generate an image (INTERLEAVED output!)
            result_pages = []
            for i, page in enumerate(pages):
                yield json.dumps({"type": "status", "message": f"🎨 Painting illustration {i+1} of {len(pages)}..."}) + "\n"

                # Generate image for this page using Gemini
                image_prompt = f"""
Create a colorful, cute, child-friendly watercolor illustration for a kids educational storybook.
Scene: {page.get('imagePrompt', page.get('title', ''))}
Topic: {topic}
Style: Bright colors, cartoon style, friendly characters, safe for children aged 6-12.
"""
                try:
                    img_response = client.models.generate_content(
                        model="gemini-2.0-flash-preview-image-generation",
                        contents=image_prompt,
                        config=types.GenerateContentConfig(
                            response_modalities=["IMAGE", "TEXT"],
                        )
                    )

                    image_data = ""
                    for part in img_response.candidates[0].content.parts:
                        if part.inline_data:
                            image_data = f"data:{part.inline_data.mime_type};base64,{part.inline_data.data}"
                            break

                    result_pages.append({
                        "title": page["title"],
                        "text": page["text"],
                        "imageUrl": image_data,
                        "illustration": "🎨✨📖"
                    })

                except Exception as img_error:
                    # Fallback if image generation fails
                    result_pages.append({
                        "title": page["title"],
                        "text": page["text"],
                        "imageUrl": "",
                        "illustration": "🎨✨📖"
                    })

                # Stream each page as it's ready (INTERLEAVED!)
                yield json.dumps({
                    "type": "page",
                    "page": result_pages[-1],
                    "pageNumber": i + 1,
                    "totalPages": len(pages)
                }) + "\n"

            # Step 3: Stream the quiz
            yield json.dumps({"type": "status", "message": "🧠 Creating quiz questions..."}) + "\n"
            yield json.dumps({"type": "quiz", "quiz": quiz}) + "\n"

            # Step 4: Done!
            yield json.dumps({"type": "complete", "message": "📚 Your storybook is ready!"}) + "\n"

        except Exception as e:
            yield json.dumps({"type": "error", "message": str(e)}) + "\n"

    return StreamingResponse(
        stream_storybook(),
        media_type="text/plain",
        headers={"X-Content-Type-Options": "nosniff"}
    )

# ── Run the server ───────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
